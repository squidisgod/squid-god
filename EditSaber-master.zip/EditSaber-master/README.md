# 3D beatsaber song editor

# This editor is deprecated, please use an alternative like MediocreMapper : https://github.com/Assistant/MediocreMapAssistant2

![alt text](https://github.com/Ikeiwa/3D-beatsaber-song-editor/blob/master/logo.png?raw=true)
